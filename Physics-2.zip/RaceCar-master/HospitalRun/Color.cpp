#include "Color.h"

Color Red = Color(1.0f, 0.0f, 0.0f);
Color Green = Color(0.0f, 1.0f, 0.0f);
Color Blue = Color(0.0f, 0.0f, 1.0f);
Color DarkBlue = Color(0.2f, 0.3f, 0.5f);
Color Yellow = Color(1.0f, 1.0f, 0.0f);
Color Orange = Color(1.0f, 0.5f, 0.0f);
Color Black = Color(0.0f, 0.0f, 0.0f);
Color White = Color(1.0f, 1.0f, 1.0f);
Color Gray = Color(0.5f, 0.5f, 0.5f);
Color Beige = Color(1.0f, 0.9f, 0.8f);
Color Brown = Color(0.2f, 0.1f, 0.0f);
Color Turquoise = Color(0.1f, 1.0f, 1.0f);
Color Sky = Color(0.0f, 0.67f, 1.0f);
Color Pink = Color(0.9f, 0.25f, 1.0f);
